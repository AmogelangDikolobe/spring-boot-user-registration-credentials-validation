
var btn = document.querySelector('#submit');
btn.addEventListener('click',ValidateEmail(document.registrationForm.email));
btn.addEventListener('click',validatePassword);
 
 


function validatePassword(password) {
                
                //does not show anything when the field is empty
                if (password.length === 0) {
                    document.getElementById("msg").innerHTML = "  ";
                              return;
                }
                // putting required values in an array
                var matchedCase = new Array();
                matchedCase.push("[$@$!%*#?&]"); 
                matchedCase.push("[A-Z]");      
                matchedCase.push("[0-9]");      
                matchedCase.push("[a-z]");     

                // Checking the conditions
                var ctr = 0;
                for (var i = 0; i < matchedCase.length; i++) {
                    if (new RegExp(matchedCase[i]).test(password)) {
                        ctr++;
						document.getElementById("submit").disabled=false;
                    }
                }
                // this case satement shows messages as the user types
                var color = "";
                var strength = "";
                switch (ctr) {
                    case 0:
                    case 1:
                    case 2:
                        strength = "Very Weak,Strengthen Your Password by including numbers,characters,uppercase,lowercase";
                        color = "red";
                        break;
                    case 3:
                        strength = "Medium";
                        color = "orange";
                        break;
                    case 4:
                        strength = "Strong";
                        color = "green";
                        break;
                }
                document.getElementById("msg").innerHTML = strength;
                document.getElementById("msg").style.color = color;
                
               }
 
 
 function ValidateEmail(inputText)
 {
 var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
 if(inputText.value.match(mailformat))
 {
 document.registrationForm.email.focus();
 return true;
 }
 else
 {
 alert("You have entered an invalid email address! Email must contain '@' and .com");
 document.registrationForm.email.focus();
 return;
 }
 window.onload = function() {
	    document.getElementById('registrationForm').onsubmit = validateEmail;
	}
 }
 
 function openForm() {
	  document.getElementById("myForm").style.display = "block";
	}

	function closeForm() {
	  document.getElementById("myForm").style.display = "none";
	}