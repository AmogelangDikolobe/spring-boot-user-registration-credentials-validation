package com.dikolobe.Validations;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface System_UserRepository extends JpaRepository<System_User, Integer>{

public System_User findByEmail(String email);//search user by the email from the database

}
