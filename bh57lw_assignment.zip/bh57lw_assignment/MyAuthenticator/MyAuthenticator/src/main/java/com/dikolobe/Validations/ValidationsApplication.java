package com.dikolobe.Validations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidationsApplication.class, args);
		System.out.println("connected");
	}

}
