package com.dikolobe.Validations;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private DataSource dataSource;

	@Value("${spring.queries.user}")//get the user queries from the application.properties to get login details from the database
	private String user;

	@Value("${spring.queries.role}")//get the role queries from the application.properties to get login details from the database
	private String role;

	@Override
	protected void configure(AuthenticationManagerBuilder authentication) throws Exception {
		authentication.jdbcAuthentication().usersByUsernameQuery(user).authoritiesByUsernameQuery(role)
				.dataSource(dataSource).passwordEncoder(bCryptPasswordEncoder);
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {

		http.authorizeRequests()
		// permitting access to pages
		.antMatchers("/").permitAll()
		.antMatchers("/login").permitAll()
		.antMatchers("/registration").permitAll()
		.antMatchers("/index/**").hasAnyAuthority("ULTIMATE_USER", "ADMIN", "NORMAL_USER")
		.anyRequest().authenticated()
		.and()
		//login form
		.csrf().disable().formLogin()
		.loginPage("/login")
		.failureUrl("/login?error")
		.defaultSuccessUrl("/index")
		.usernameParameter("email")
		.passwordParameter("password")
		.and();
					}

	@Override
	public void configure(WebSecurity webSecurity) throws Exception {
		webSecurity.ignoring().antMatchers("/resources/**", "/static/**", "/css/**","/javaScript/**", "/images/**");// ignoring folders so that they won't be shown on the browser
	}

}
