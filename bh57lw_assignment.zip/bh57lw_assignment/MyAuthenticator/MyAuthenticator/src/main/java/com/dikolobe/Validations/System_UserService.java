package com.dikolobe.Validations;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class System_UserService {

@Autowired
private	RoleRepository roleRepository;

@Autowired	
System_UserRepository userRepository;

@Autowired
BCryptPasswordEncoder passwordEncoder;

public List<System_User> listAll(){/*get all the users from the database*/
	return userRepository.findAll();
}
public void save(System_User user) {
	user.setPassword(passwordEncoder.encode(user.getPassword()));//password encryption
	user.setStatus("VERIFIED");//setting the status of the user as VERIFIED in the database
	Role userRole = roleRepository.findByRole("NORMAL_USER");//authorising the user as NORMAL_USER 
	user.setUser_role(new HashSet<Role>(Arrays.asList(userRole)));//setting the role of the user in the database
	userRepository.save(user);
}
public System_User get(int id) {
	return userRepository.findById(id).get();//searching the user by the id in the database
	}

public boolean checkUserPresence(System_User user) {//search the user by the email from the database
     boolean alreadyExists = false;
     System_User present = userRepository.findByEmail(user.getEmail());
     if(present != null){
    	 alreadyExists = true;//if the email is present then it returns true 
     }
     return alreadyExists;
}
}

