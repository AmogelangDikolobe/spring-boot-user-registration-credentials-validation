package com.dikolobe.Validations;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Integer> {

public	Role findByRole(String role);//search user by role from the database

}
