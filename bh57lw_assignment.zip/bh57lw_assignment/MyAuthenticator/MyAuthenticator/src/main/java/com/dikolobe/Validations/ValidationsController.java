package com.dikolobe.Validations;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class ValidationsController {
	@Autowired
	private System_UserService service;
	
@RequestMapping("/index")//call the index page which shows list of registered users
public String viewHomePage(Model model) {
	List<System_User> listUsers = service.listAll();/*get all users from the listAll method service repository and save in listUsers variable*/
	model.addAttribute("listUsers", listUsers);/*takes the listUsers variable with its values and saves it in listUsers object so it can be passed to the index*/
		return "index";//returns index page with registered users
	
	
}

@RequestMapping("/registration") //shows registration page
public String showRegistrationForm(Model model) {
  System_User users = new System_User();
	model.addAttribute("users", users);
	
	return "registration";
	
}

@RequestMapping(value = "/save", method = RequestMethod.POST)//this calls the save method
public String savePerson(@ModelAttribute("user")@Valid System_User user, BindingResult bindingResult, Model model) {
	ModelAndView modelAndView = new ModelAndView();
	if(service.checkUserPresence(user)){//calls the checkUserPresence method from the user service
		model.addAttribute("invalid", true);//if email is present it notifies the user
		
		return "/registration";}//shows registration page and never saves 
	
	else {
		service.save(user);//otherwise save user if email does not exist
	
	return "redirect:/index";//shows index/users page
}}

@RequestMapping(value = { "/login" }, method = RequestMethod.GET)//shows the login page
public String login(@ModelAttribute("user")@Valid System_User user, BindingResult bindingResult,Model model) {
	ModelAndView modelAndView = new ModelAndView();
	
	if (model.addAttribute("invalid", true) != null) {//shows the error message,wrong credentials
		return "/login";}//remains on the login page
		else { 
			modelAndView.setViewName("login");
		return "/login";
	}}

}
